Visual Basic XML-RPC Client

Register the dll before use.....

Copyright Clifford E. Baeseman <codepunk@codepunk.com>
Please supply all bug fix requests to codepunk@codepunk.com you
will find me very responsive to problems.

Licensed under the LGPL See the included license file. 

Developer Credits
 Major Source Contributions and Patches
 by Patrick Martin
 
 Server Thread Syncronization
 Memory Hole Cleanup
  
 This library contains a mime encoder by
 Ralf Junker <ralfjunker@gmx.de> 2000-2001
 http://www.zeitungsjunge.de/delphi/ 

 This library also contains the excellent xml parser
 written by Stefan Heymann.
 http://www.destructor.de


YOU MUST INSTALL THE LATEST INDY COMPONENTS TO COMPILE!
http://www.nevrona.com/Indy/


Change Log:

   Added a complex example

  Visual Basic Initial Release